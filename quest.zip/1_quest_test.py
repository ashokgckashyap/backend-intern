#Given m(max value of each digit) and n(length of the number) can you generate all number of length n whose each digit is less or equal to m.
#        m -> Max value of each digit
#        n -> Length of the number 
#Input : m = 1 , n = 1 , Output : 00 , 01, 10, 11
#Input : m = 2 , n = 2 , Output : 00 , 01, 02 , 10, 11, 12, 20, 21, 22
#Input : m = 2 , n = 3 , Output : 000, 001, 002, 010, 011, 012, 020, 021, 022 , .... 222

import itertools
       
m1=int(input("Enter the value of m:"))
m2=0
m3=[]
while m2<m1+1:
   m3.append(m2)
   m2=m2+1
n=int(input("Enter the value of n:"))

if (m1==1 & n==1):
    a=[''.join((str(digit)) for digit in list(number))for number in itertools.product([0,1],repeat=n+1)]
    for i in a:
        print (i,end=" ")
else:
    a=[''.join((str(digit)) for digit in list(number))for number in itertools.product(m3,repeat=n)]
    for i in a:
        print (i,end=" ")    
